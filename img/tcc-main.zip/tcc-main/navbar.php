<style>
  .navbar navbar-expand-lg bg-body-tertiary {
    color: black;
  }
</style>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
         <!-- botoes da parte esquerda -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="">Inicio</a>
        </li>
      
      </ul>
      <!-- botoes da parte direita -->
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="crud/editcad.php">Editar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="crud/perfil.php">Perfil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="crud/formcad.php">Cadastrar</a>
        </li>
      </ul>
      </form>
    </div>
  </div>
</nav>