<?php
$conn = [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'db' => 'assistencia',
    'email' => '',
    'senha_email' => ''
];