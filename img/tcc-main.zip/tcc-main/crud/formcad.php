<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../java/login.js" defer></script>
    <link href="../css/cadastraR.css" rel="stylesheet">
   
    <title></title>
</head>
<body>

<header>
  
</header>

 
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Estilos CSS personalizados -->

</head>
<form class="form-signin" action="cadastrar.php" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">Cadastrar-se</h1>
    <label for="Nome" class="sr-only">Nome</label>
    <input type="name" name="Nome"class="form-control" placeholder="Nome" required autofocus>

    <label for="SIAPE" class="sr-only">SIAPE</label>
    <input type="text"  name="SIAPE" class="form-control" placeholder="SIAPE" required>

    <label for="Perfil" class="sr-only">Perfil</label>
    <input type="text"  name="Perfil" class="form-control" placeholder="Perfil" required>

    <label for="Email" class="sr-only">Email</label>
    <input type="Email"  name="Email" class="form-control" placeholder="Email" required>

    <label for="Senha" class="sr-only">Senha</label>
    <input type="password"  name="Senha" class="form-control" placeholder="Senha" required>


  
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Cadastrar</button> 
    <a class="btn btn-lg  btn-block" href="../index.php">Entrar</a>  








    
    <footer>

    </footer>
</body>
</html>






